
# Brain tumor Detection

## Contributing

Contributions are weklcomed "open handed"!

fork this repo, include your contributions and opena  `pull request` and mention your contro in discription

